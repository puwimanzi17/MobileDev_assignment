package com.example.attendanceapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Cohort2Database mydb;
    Button btnsave, readBtn, deleteBtn, updateBtn;
    EditText email,id,name,password;
    TextView gender, department, session;
    RadioGroup radios;
    Spinner one;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mydb = new Cohort2Database(this);

        id = (EditText) findViewById(R.id.tapcard);
        email = (EditText) findViewById(R.id.email_address);
        name = (EditText) findViewById(R.id.student_name);
        password = (EditText) findViewById(R.id.password);
        radios=(RadioGroup) findViewById(R.id.radiogroup);
        gender= (TextView)  findViewById(R.id.gender);
        department = (TextView) findViewById(R.id.department);
        session = (TextView) findViewById(R.id.session);
        btnsave= findViewById(R.id.add_button);
        updateBtn = findViewById(R.id.update_button);
        deleteBtn = findViewById(R.id.delete_button);
        readBtn = findViewById(R.id.read_button);
        one= findViewById(R.id.spinner_one);
        readSavedData();
        deleteData();
        updateData();

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int checked = radios.getCheckedRadioButtonId();
//
//                if (email.length() == 0 || id.length() == 0 || name.length() == 0 || password.length() == 0 || checked == -1) {
//                    email.setError("Email");
//                    id.setError("Enter Reg number");
//                    name.setError("Enter a valid name");
//                    password.setError("Enter a valid password");
//                    gender.setTextColor(Color.RED);
//                    department.setTextColor(Color.RED);
//                    session.setTextColor(Color.RED);
//
//                } else{
                    insertData();
//                }



//                else {
//                    Notify nextFrag= new Notify(); getSupportFragmentManager().beginTransaction() .replace(R.id.frame, nextFrag, "findThisFragment") .addToBackStack(null) .commit();
//
//
//                }

            }
        });
    }



    public void insertData(){

        boolean insertData = mydb.insertData(name.getText().toString(), password.getText().toString(), email.getText().toString());

        if(insertData == true){
            toastMessage("Data successfully inserted");
        }else{
            toastMessage("something went wrong");
        }

    }

    public void updateData(){
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isupdated= mydb.updatedata(id.getText().toString(),name.getText().toString(),email.getText().toString(),password.getText().toString());
                if(isupdated==true){
                    Toast.makeText(MainActivity.this,"Data updated successfully",Toast.LENGTH_LONG).show();


                }
                else {
                    Toast.makeText(MainActivity.this,"Data not updated recorded",Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    public void deleteData(){
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deleted = mydb.deleteData(id.getText().toString());
                if(deleted>0){
                    Toast.makeText(MainActivity.this,"Data Deleted successfully",Toast.LENGTH_LONG).show();


                }
                else {
                    Toast.makeText(MainActivity.this,"Data not deleted recorded",Toast.LENGTH_LONG).show();

                }

            }
        });
    }

    public void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void readSavedData(){
        readBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer buffer = new StringBuffer();
                Cursor res = mydb.readData();
                if (res.getCount()==0){
                    showRecords("Error","no data");
                    return;
                }
                while (res.moveToNext()){
                    buffer.append("Id:"+res.getString(0)+"\n");
                    buffer.append("name:"+res.getString(1)+"\n");
                    buffer.append("email:"+res.getString(2)+"\n");
                    buffer.append("password:"+res.getString(3)+"\n\n");

                }
                showRecords("Data",buffer.toString());

            }
        });
    }



    public void showRecords(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setMessage(message);
        builder.setTitle(title);
        builder.show();
    }

}

