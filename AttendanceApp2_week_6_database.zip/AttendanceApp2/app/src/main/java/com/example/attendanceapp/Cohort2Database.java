package com.example.attendanceapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Cohort2Database extends SQLiteOpenHelper {

    public static final String DBNAME = "cohort3.db";
    public static final int VERSION = 3;
    public static final String TABLENAME = "Student";
    public static final String COL1 = "ID";
    public static final String COL2 = "Name";
    public static final String COL3 = "Password";
    public static final String COL4 = "email";

    public Cohort2Database(@Nullable Context context){
        super(context, DBNAME, null, VERSION);

    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + TABLENAME + "(ID integer primary key autoincrement, email String, Password String, Name String)");
//        db.execSQL("CREATE TABLE if not exists " + TABLENAME + "(" + COL1 INTEGER+ COL2 + " TEXT, " + COL3 + " TEXT, " +COL4 + " TEXT)");

    }
    @Override
    public void onUpgrade( SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists "+ TABLENAME);
        onCreate(db);
    }

    public boolean insertData(String name, String password, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues records = new ContentValues();

        records.put(COL2, name);
        records.put(COL3, password);
        records.put(COL4, email);

        long result = db.insert(TABLENAME, null, records);
        if(result == -1){
            return false;
        }else {
            return true;
        }

    }
    public boolean updatedata( String id, String name , String password, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(COL1, id);
        contentValues.put(COL2,name);
        contentValues.put(COL3,password);
        contentValues.put(COL4,email);
        db.update(TABLENAME,contentValues,"ID = ?",new String[] {id});
        return true;

    }

    public Cursor readData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor dataToRead = db.rawQuery("select * from " + TABLENAME, null);
        return dataToRead;
    }

    public Integer deleteData(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLENAME,"ID = ?",new String[]{id});

    }


}