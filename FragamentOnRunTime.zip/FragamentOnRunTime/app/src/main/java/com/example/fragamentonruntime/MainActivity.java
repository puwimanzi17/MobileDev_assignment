package com.example.fragamentonruntime;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    //add fragment manager
    public static FragmentManager fragmentManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Check if the container is available
        //Initialize fragment manager object
        fragmentManager=getSupportFragmentManager();
        if (findViewById(R.id.container)!=null) {
            //add a fragament
            if(savedInstanceState!=null){
                return;
            }
            //create fragment transaction
            FragmentTransaction ft=fragmentManager.beginTransaction();
            frag1 homeFragment= new frag1();
            ft.add(R.id.container,homeFragment,null);
            ft.commit();

        }
    }
}
