package com.example.fragamentonruntime;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class frag2 extends Fragment {
    private Button btnSecond;
    public static FragmentManager fm;



    public frag2() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_frag2, container, false);
        btnSecond=view.findViewById(R.id.button2);
//        btnSecond.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                MainActivity.fragmentManager.beginTransaction().replace(R.id.container,new Fragament3(),null).commit();
//            }
//        });

        btnSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                fm=getFragmentManager();
//                FragmentTransaction ft = getFragmentManager().beginTransaction();
//                ft.replace(R.id.fragament2, new Fragament3(), "NewFragmentTag");
//                ft.commit();
                Fragament3 fragament3= new Fragament3();
//                MainActivity.fragmentManager.beginTransaction().replace(R.id.container,fragament3,null).commit();
                 getActivity().getSupportFragmentManager().beginTransaction() .replace(R.id.container, fragament3, "findThisFragment") .addToBackStack(null) .commit();
            }
        });


        return view;
    }

}
